from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def root():
    return "Welcome to my CSCB20 website!"

@app.route("/<name>")
def generateResponse(name):
    new_name = name

    if any(str.isdigit(c) for c in name):
        new_name = ''.join([c for c in name if not str.isdigit(c)])
    elif str.upper(new_name) == new_name:
        new_name = str.lower(new_name)
    elif str.lower(new_name) == new_name:
        new_name = str.upper(new_name)

    return f"Welcome, {new_name}, to my CSCB20 website!"

if __name__ == '__main__':
    app.run(debug=True)